package Atividade07;

public class Main {
    public static void main(String[] args) {

        Casa casa = new Casa("Rua A, 123");
        Carro carro = new Carro("Fusca");
        Arvore arvore = new Arvore("Mangueira");

        Joao joao = new Joao("João", casa, carro);

        arvore.mostrar();
        joao.rotina();
    }
}
