package Atividade05;

public class PrincipalAnimais {
    public static void main(String[] args) {

        Gato gato = new Gato("Mingau", 2);
        Dog dog = new Dog("Rex", 3);

        gato.mostrarDados();
        gato.emitirSom();

        System.out.println("----------------");

        dog.mostrarDados();
        dog.emitirSom();
    }
}
