package Atividade07;

public class Arvore {

    String tipo;

    public Arvore(String tipo) {
        this.tipo = tipo;
    }

    public void mostrar() {
        System.out.println("Há uma árvore do tipo " + tipo);
    }
}
