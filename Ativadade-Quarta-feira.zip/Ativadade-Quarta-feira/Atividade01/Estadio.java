package Atividade01;

import java.util.Scanner;

public class Estadio {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int precoA = 50;
        int precoB = 30;
        int precoC = 20;

        System.out.print("Quantos ingressos Classe A foram vendidos? ");
        int qtdA = scanner.nextInt();

        System.out.print("Quantos ingressos Classe B foram vendidos? ");
        int qtdB = scanner.nextInt();

        System.out.print("Quantos ingressos Classe C foram vendidos? ");
        int qtdC = scanner.nextInt();

        int rendaA = qtdA * precoA;
        int rendaB = qtdB * precoB;
        int rendaC = qtdC * precoC;

        int rendaTotal = rendaA + rendaB + rendaC;

        System.out.println("\nRenda por classe:");
        System.out.println("Classe A: R$ " + rendaA);
        System.out.println("Classe B: R$ " + rendaB);
        System.out.println("Classe C: R$ " + rendaC);

        System.out.println("\nRenda total: R$ " + rendaTotal);

        scanner.close();
    }
}
