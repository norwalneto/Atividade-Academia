package sef.module3.activity;

import java.util.Scanner;

public class NumToWordsUsingMethod {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int num;

        do {
            System.out.print("Digite um número ou (0 para sair): ");
            num = scanner.nextInt();

            switch (num) {
                case 0:
                    System.out.println("Saindo...");
                    break;
                default:
                    printMyWord(num);
                    break;
            }

        } while (num != 0);

        scanner.close();
    }
    private static void printMyWord(int i) {
        final String numText;
        switch (i) {
            case 1:
                numText = "ONE";
                break;
            case 2:
                numText = "TWO";
                break;
            case 3:
                numText = "THREE";
                break;
            case 4:
                numText = "FOUR";
                break;
            case 5:
                numText = "FIVE";
                break;
            case 6:
                numText = "SIX";
                break;
            case 7:
                numText = "SEVEN";
                break;
            case 8:
                numText = "EIGHT";
                break;
            case 9:
                numText = "NINE";
                break;
            case 10:
                numText = "TEN";
                break;
            default:
                numText = "NUMBER " + i;
        }
        System.out.println(numText);
    }
}
