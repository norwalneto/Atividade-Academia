package Atividade07;

public class Casa {

    String endereco;

    public Casa(String endereco) {
        this.endereco = endereco;
    }

    public void abrirPorta() {
        System.out.println("Abrindo a porta da casa em " + endereco);
    }
}
