package sef.module3.activity;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class NumerosInteiros2 {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        //iniciando variaveis:
        int saoPares = 0;
        ArrayList<Integer> numerosPares = new ArrayList<>();

        //lendo a Quantidade de entrada:
        System.out.println();
        System.out.print("Quantos números você deseja digitar: ");
        int quantidadeDeNumeros = input.nextInt();

        //Criando vetor recebendo a entrada:
        int[] numeros = new int[quantidadeDeNumeros];

        //criando laco for para armazenar as posicoes e armazenar a quantidade de pares:
        for (int i = 0; i < numeros.length; i++) {
            System.out.printf("Entre com a posição %d: ", i + 1);
            numeros[i] = input.nextInt();

            saoPares += (numeros[i] % 2 == 0) ? 1 : 0;
            numerosPares.addAll((numeros[i] % 2 == 0)
                    ? Arrays.asList(numeros[i])
                    : new ArrayList<>());
        }

        System.out.println();

        String mensagemNumeros = (numeros.length == 1)
                ? "O número digitado é: "
                : "Os números digitados são: ";

        System.out.println(mensagemNumeros + Arrays.toString(numeros));

        String mensagemPares = (saoPares == 0)
                ? "Nenhum número par foi digitado."
                : (saoPares == 1)
                ? "A quantidade de números pares é 1.\n" + numerosPares + " é um número par"
                : "Desses números, " + saoPares + " são pares.\nOs números pares são: " + numerosPares;

        System.out.println(mensagemPares);

        input.close();
    }
}
