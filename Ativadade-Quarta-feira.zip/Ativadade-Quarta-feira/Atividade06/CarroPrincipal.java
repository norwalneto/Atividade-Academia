package Atividade06;

public class CarroPrincipal {

    public static void main(String[] args) {

        Carro carro = new Carro("Honda", "Vermelho", 75000);

        carro.exibir();

        System.out.println("----------------");

        carro.buzinar();

        System.out.println("----------------");

        carro.movimentar();

        System.out.println("----------------");

        carro.ligar();

        System.out.println("----------------");

        carro.movimentar();

        System.out.println("----------------");

        carro.buzinar();
    }
}
