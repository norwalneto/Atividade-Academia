package Atividade06;

public class Carro {

    String marca;
    String codigoCor;
    double preco;
    boolean ligado;
    boolean emMovimento;

    public Carro(String marca, String codigoCor, double preco) {
        this.marca = marca;
        this.codigoCor = codigoCor;
        this.preco = preco;

        ligado = false;
        emMovimento = false;
    }

    public void exibir() {
        System.out.println("Marca: " + marca);
        System.out.println("Cor: " + codigoCor);
        System.out.println("Preço: " + preco);
    }

    public void ligar() {
        ligado = true;
        System.out.println("Carro ligado!");
    }

    public void movimentar() {
        switch (ligado ? 1 : 0) {
            case 1:
                emMovimento = true;
                System.out.println("O carro está em movimento.");
                break;
            case 0:
                System.out.println("O carro precisa estar ligado.");
                break;
        }
    }
    public void buzinar() {
        switch (emMovimento ? 1 : 0) {
            case 1:
                System.out.println("Emitir som: Biiii!");
                break;
            case 0:
                System.out.println("O carro precisa estar em movimento para buzinar.");
                break;
        }
    }
}
