/**
 * 
 */
package sef.module3.activity;

import java.util.Scanner;

public class Calculator {
		
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		int opcao;
		
		int x = 10;
		int y = 5;
	
		int[] nums = {1, 2, 3, 4};
		
		do {
			System.out.println("\n=== MENU CALCULADORA ===");
			System.out.println("1 - Soma");
			System.out.println("2 - Subtração");
			System.out.println("3 - Multiplicação");
			System.out.println("4 - Divisão");
			System.out.println("0 - Sair");
			System.out.print("Escolha uma opção: ");

			opcao = sc.nextInt();

			switch (opcao) {
				case 1:
					System.out.println("Addition - " + add(x, y));
					break;
				case 2:
					System.out.println("Subtraction - " + subtract(x, y));
					break;
				case 3:
					System.out.println("Multiply - " + multiply(nums));
					break;
				case 4:
					System.out.println("Divide - " + divide(x, y));
					break;
				case 0:
					System.out.println("Encerrando...");
					break;
				default:
					System.out.println("Opção inválida!");
			}

		} while (opcao != 0);

		sc.close();
	
	
	}


	private static int add(int x, int y) {
		int sum = x + y;
		return sum;
	}

	private static int subtract(int x, int y) {
		int diff = 0;
		switch (Integer.compare(x, y)) {
		case 1:
			diff = x - y;
			break;
		default:
			diff = y - x;
			break;
	}

		return diff;
	}

	private static int multiply(int[] numbers) {
		int temp = 1;

		for (int i = 0; i < numbers.length; i++) {
			temp = temp * numbers[i];
		}
		return temp;

	}

	private static int divide(int x, int y) {
		int divValue = 0;
		switch (x * y) {
			case 0:
				System.out.println("Não é possível dividir por zero!");
				break;
			default:
				divValue = x / y;
				break;
		}
		
		return divValue;
	}
	
}

