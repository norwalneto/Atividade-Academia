package Atividade04;

import java.util.Scanner;

public class LocalizaNumero {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        int vetor[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        boolean achou = false;
        int posicao = -1;

        System.out.print("Digite o número que deseja buscar: ");
        int numero = scanner.nextInt();

        for (int i = 0; i < vetor.length; i++) {
            if (vetor[i] == numero) {
                achou = true;
                posicao = i;
                break;
            }
        }

        if (achou) {
            System.out.println("Achei!");
            System.out.printf("Na posição %d está localizado o número %d\n", posicao, numero);
        } else {
            System.out.println("Numero não encontrado.");
        }

        scanner.close();
    }
}
