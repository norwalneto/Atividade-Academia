package Atividade07;

public class Joao {
    String nome;
    Casa casa;
    Carro carro;

    public Joao(String nome, Casa casa, Carro carro) {
        this.nome = nome;
        this.casa = casa;
        this.carro = carro;
    }

    public void rotina() {
        System.out.println(nome + " acordou.");

        casa.abrirPorta();
        System.out.println(nome + " saiu de casa.");

        carro.dirigir();
        System.out.println(nome + " foi trabalhar.");
    }

}
