package Atividade05;

public class Dog {

    String nome;
    int idade;

    public Dog(String nome, int idade) {
        this.nome = nome;
        this.idade = idade;
    }

    public void mostrarDados(){
        System.out.println("Nome: " + nome);
        System.out.println("Idade: " + idade);
    }

    public void emitirSom() {
        System.out.println("Som: uau");
    }
}
